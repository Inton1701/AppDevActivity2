const express = require('express');
const router = express.Router();
let todos = [];
router.get('/', (req, res) => {
    res.render('index', { todos });});
router.get('/add', (req, res) => {
    res.render('add');
});
router.post('/add', (req, res) => {
    const {todo} = req.body;
    if (todo) {
        todos.push(todo);
    }
    res.redirect('/');
});
router.post('/delete/:index', (req, res) => {
    const {index} = req.params;
    if (index >= 0 && index < todos.length) {
        todos.splice(index, 1);}
    res.redirect('/');
});
module.exports = router;
